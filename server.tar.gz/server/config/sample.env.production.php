<?php

return array(
    'DPLA_KEY'              => 'asdasde091241432097234',
    'ELASTICSEARCH_HOST'    => 'http://twf3on0305onei.bc.edu:9200/',
    'ELASTICSEARCH_VERSION' => '1.5.1',
    'PRIMO_HOST'            => 'your-url.hosted.exlibrisgroup.com',
    'PRIMO_INSTITUTION'     => 'BCL',
    'REDIS_HOST'            => 'localhost',
    'WORLDCAT_KEY'          => 'hqt3zFO8NMheYSQFD1WF7UM9apJMEIGVSpAKzFyyDfy1DOCE52Vuof6mP5lKnyDVmoXfYMt68UUUSUqa3QL',
    'WORLDCAT_SECRET'       => 'KjqEmGzQD17OWsCJsYSU07TAF',
    'WORLDCAT_INST_NUM'     => '31870',
    'WORLDCAT_INST_CODE'    => 'FOO'
);