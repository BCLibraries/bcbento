<?php

return array(
    'DPLA_KEY'              => '116e3d9fe8e86063f83e0b72eb9b5ba8',
    'ELASTICSEARCH_HOST'    => 'http://libdw.bc.edu:9200/',
    'ELASTICSEARCH_VERSION' => '1.5.4',
    'PRIMO_HOST'            => 'bc-primo.hosted.exlibrisgroup.com',
    'PRIMO_INSTITUTION'     => 'BCL',
    'REDIS_HOST'            => 'localhost',
    'WORLDCAT_KEY'          => 'bbnF0cNHbReYchdBidnDhDa59y2w9crX22Dwm43K8GaJzZHw6mlGObJU02zHTilBAgIf9eqKjpGaAJHu',
    'WORLDCAT_SECRET'       => 'aJoLRNB6BrZZ/qh19QTf3w==',
    'WORLDCAT_INST_NUM'     => '89234',
    'WORLDCAT_INST_CODE'    => 'BXM'
);