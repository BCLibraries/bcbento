<?php

namespace BCLib\BCBento;

use Slim\Middleware;

class Service extends Middleware
{

    public function call()
    {

    }
}