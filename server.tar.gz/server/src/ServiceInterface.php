<?php

namespace BCLib\BCBento;

interface ServiceInterface
{
    public function fetch($keyword);
}